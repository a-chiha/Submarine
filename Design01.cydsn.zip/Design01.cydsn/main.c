/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "project.h"
#include <stdio.h>
char buffer[20];
void oneWireInit()
{
    // Træk datalinjen lav i 480 mikrosekunder
    tempData_Write(0);
    CyDelayUs(480);
    tempData_Write(1);
    CyDelayUs(60); // Vent og læs sensoren
    sprintf(buffer, "Dataline: %d\n\r", tempData_Read());
    UART_1_PutString(buffer);
    buffer[0] = '\0';
}

int oneWire_read()
{
    int data=0;
    for (int i = 0; i < 8; i++) {
        // Start read time slot
        tempData_Write(0);        // Pull line low to signal read start
        CyDelayUs(2);             // Keep low for ~2 microseconds
        tempData_Write(1);        // Release line, allowing it to go high

        CyDelayUs(15);            // Wait for 15 microseconds to allow the sensor to pull the line low or keep it high

        // Read the bit value
        if (tempData_Read()) {    // If line is high, bit is '1'
            data |= (1 << i);     // Set the corresponding bit in 'data'
        }

        CyDelayUs(45);            // Wait for the remainder of the time slot (total ~60 microseconds)
    }
    char buffer[50];
    sprintf(buffer, "OneWire read: %d\n\r", data);  // Debug output for the read value
    UART_1_PutString(buffer);
    return data;
    

}

int oneWire_write(int data)
{
    for (int i = 0; i < 8; i++) {
        // Check if the current bit is 1 or 0
        if (data & (1 << i)) {   // Write a '1' bit
            tempData_Write(0);    // Pull line low to start
            CyDelayUs(2);         // Keep low for ~2 microseconds
            tempData_Write(1);    // Release the line, allowing it to go high
            CyDelayUs(60);        // Complete the time slot with the line high
        } else {                  // Write a '0' bit
            tempData_Write(0);    // Pull line low to start
            CyDelayUs(60);        // Hold low for ~60 microseconds
            tempData_Write(1);    // Release the line at the end of the time slot
        }
    }
    UART_1_PutString("OneWire write\n\r");
    return 0;   
    
}
void convertBitsToTemp(int lsb, int msb)
{
     int16_t rawTemperature = (msb << 8) | lsb;
     float celsius = rawTemperature / 16.0;
    sprintf(buffer,"Temperatur: %.2f C\n\r", celsius);
    UART_1_PutString(buffer);
}
void test_til_temp(){
    oneWireInit();           // Start med reset-puls
    oneWire_write(0xCC);      // Skip ROM for at vælge sensoren
    oneWire_write(0x44);      // Start temperaturkonvertering
    CyDelay(750);             // Vent til måling er færdig
    
    oneWireInit();           // Reset igen før næste kommando
    oneWire_write(0xCC);      // Skip ROM igen
    oneWire_write(0xBE);      // Læs scratchpad

    int lsb = oneWire_read(); // Læs LSB byte
    int msb = oneWire_read(); // Læs MSB byte

    convertBitsToTemp(lsb, msb); // Konverter og vis temperatur
}
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_1_Start();
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
     
        test_til_temp();
        UART_1_PutString("\n\n\r");
        CyDelay(1000);
    for(;;)
    {   
    }
}

