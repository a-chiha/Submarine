/*******************************************************************************
* File Name: tempData.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_tempData_H) /* Pins tempData_H */
#define CY_PINS_tempData_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "tempData_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 tempData__PORT == 15 && ((tempData__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    tempData_Write(uint8 value);
void    tempData_SetDriveMode(uint8 mode);
uint8   tempData_ReadDataReg(void);
uint8   tempData_Read(void);
void    tempData_SetInterruptMode(uint16 position, uint16 mode);
uint8   tempData_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the tempData_SetDriveMode() function.
     *  @{
     */
        #define tempData_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define tempData_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define tempData_DM_RES_UP          PIN_DM_RES_UP
        #define tempData_DM_RES_DWN         PIN_DM_RES_DWN
        #define tempData_DM_OD_LO           PIN_DM_OD_LO
        #define tempData_DM_OD_HI           PIN_DM_OD_HI
        #define tempData_DM_STRONG          PIN_DM_STRONG
        #define tempData_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define tempData_MASK               tempData__MASK
#define tempData_SHIFT              tempData__SHIFT
#define tempData_WIDTH              1u

/* Interrupt constants */
#if defined(tempData__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in tempData_SetInterruptMode() function.
     *  @{
     */
        #define tempData_INTR_NONE      (uint16)(0x0000u)
        #define tempData_INTR_RISING    (uint16)(0x0001u)
        #define tempData_INTR_FALLING   (uint16)(0x0002u)
        #define tempData_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define tempData_INTR_MASK      (0x01u) 
#endif /* (tempData__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define tempData_PS                     (* (reg8 *) tempData__PS)
/* Data Register */
#define tempData_DR                     (* (reg8 *) tempData__DR)
/* Port Number */
#define tempData_PRT_NUM                (* (reg8 *) tempData__PRT) 
/* Connect to Analog Globals */                                                  
#define tempData_AG                     (* (reg8 *) tempData__AG)                       
/* Analog MUX bux enable */
#define tempData_AMUX                   (* (reg8 *) tempData__AMUX) 
/* Bidirectional Enable */                                                        
#define tempData_BIE                    (* (reg8 *) tempData__BIE)
/* Bit-mask for Aliased Register Access */
#define tempData_BIT_MASK               (* (reg8 *) tempData__BIT_MASK)
/* Bypass Enable */
#define tempData_BYP                    (* (reg8 *) tempData__BYP)
/* Port wide control signals */                                                   
#define tempData_CTL                    (* (reg8 *) tempData__CTL)
/* Drive Modes */
#define tempData_DM0                    (* (reg8 *) tempData__DM0) 
#define tempData_DM1                    (* (reg8 *) tempData__DM1)
#define tempData_DM2                    (* (reg8 *) tempData__DM2) 
/* Input Buffer Disable Override */
#define tempData_INP_DIS                (* (reg8 *) tempData__INP_DIS)
/* LCD Common or Segment Drive */
#define tempData_LCD_COM_SEG            (* (reg8 *) tempData__LCD_COM_SEG)
/* Enable Segment LCD */
#define tempData_LCD_EN                 (* (reg8 *) tempData__LCD_EN)
/* Slew Rate Control */
#define tempData_SLW                    (* (reg8 *) tempData__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define tempData_PRTDSI__CAPS_SEL       (* (reg8 *) tempData__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define tempData_PRTDSI__DBL_SYNC_IN    (* (reg8 *) tempData__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define tempData_PRTDSI__OE_SEL0        (* (reg8 *) tempData__PRTDSI__OE_SEL0) 
#define tempData_PRTDSI__OE_SEL1        (* (reg8 *) tempData__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define tempData_PRTDSI__OUT_SEL0       (* (reg8 *) tempData__PRTDSI__OUT_SEL0) 
#define tempData_PRTDSI__OUT_SEL1       (* (reg8 *) tempData__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define tempData_PRTDSI__SYNC_OUT       (* (reg8 *) tempData__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(tempData__SIO_CFG)
    #define tempData_SIO_HYST_EN        (* (reg8 *) tempData__SIO_HYST_EN)
    #define tempData_SIO_REG_HIFREQ     (* (reg8 *) tempData__SIO_REG_HIFREQ)
    #define tempData_SIO_CFG            (* (reg8 *) tempData__SIO_CFG)
    #define tempData_SIO_DIFF           (* (reg8 *) tempData__SIO_DIFF)
#endif /* (tempData__SIO_CFG) */

/* Interrupt Registers */
#if defined(tempData__INTSTAT)
    #define tempData_INTSTAT            (* (reg8 *) tempData__INTSTAT)
    #define tempData_SNAP               (* (reg8 *) tempData__SNAP)
    
	#define tempData_0_INTTYPE_REG 		(* (reg8 *) tempData__0__INTTYPE)
#endif /* (tempData__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_tempData_H */


/* [] END OF FILE */
